@extends('admin.layouts.main')

@section('body')

<body class="bg-gradient-primary">
    @yield('content')
</body>
@endsection